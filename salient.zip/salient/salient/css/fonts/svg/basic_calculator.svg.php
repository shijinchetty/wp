<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<svg version="1.1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="64px" height="64px" viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
<g>
	<rect x="1" y="1" fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" width="62" height="62"/>
</g>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="18" y1="8" x2="18" y2="28"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="28" y1="18" x2="8" y2="18"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="56" y1="18" x2="36" y2="18"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="10" y1="54" x2="26" y2="38"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="10" y1="38" x2="26" y2="54"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="36" y1="43" x2="56" y2="43"/>
<line fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" x1="36" y1="49" x2="56" y2="49"/>
</svg>
